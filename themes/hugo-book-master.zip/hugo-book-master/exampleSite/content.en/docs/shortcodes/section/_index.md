---
bookCollapseSection: true
bookHidden: true
---

# Section

Section renders pages in section as definition list, using title and description. Optional param `summary` can be used to show or hide page summary

## Example

```tpl
{{</* section [summary] */>}}
```

{{<section summary>}}
